#include "Enemy.h"
#include <cstdlib>
#include <conio.h>
#include <ctime>

//BITCH I SAID NO SPOILERS!! GET OUTTA HERE!!!
void Enemy::Exist()
{
	
}

/*void Enemy::determineStartPos(int randPos)
{
	srand(time(0));

	if (!(randPos > 0))
	{
		randPos = (rand() % 3) + 1;
	}
	else
	{
		switch (randPos)
		{
		case 1:
			x = 
			break;
		}
	}

}*/
