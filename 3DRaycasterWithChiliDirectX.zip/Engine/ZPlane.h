#pragma once
#include "Graphics.h"
#include "Surface.h"
#include <math.h>
#define PI 3.14159265
#define P2 PI/2
#define P3 (3 * PI)/2
#define DR 0.0174533

class Plane
{
public:
	//Tbh, most of these variables are bullshit, but idk which ones
	//and i don't want to delete them and end up breaking shit :/
	float x = 350.0f;
	float y = 370.0f;
	float angle = 0.0f;
	int height;
	//For every new texture you add, increase "textCol[thisNumber]" by 64^2 (4,096)
	Color textCol[12288];
	bool thirdPerson = false;
	int sd = 0;
	int textVal = 0;
	void init(Surface texture);
	float disT;
	bool canWalk = true;
	float dx = cos(angle) * 5, dy = sin(angle) * 5;
	float dist(float ax, float ay, float bx, float by, float ang);
	void drawRays3d(Graphics& gfx, Surface texture);
	int mapX = 12, mapY = 10, mapS = 120;
	//0; empty space, 1; texture slot 1, 2; texture slot 2, etc.
	int map[120] =
	{
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
		1, 0, 0, 2, 0, 0, 0, 0, 2, 0, 0, 1,
		1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
		1, 0, 0, 0, 3, 3, 0, 0, 0, 0, 0, 1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
	};
};