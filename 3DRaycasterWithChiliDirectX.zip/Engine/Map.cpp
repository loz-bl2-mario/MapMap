#include "Map.h"
#include "MainWindow.h"

Map::Map(MainWindow & wnd)
	:
	wnd( wnd )
{
}
void Map::scroll()
{
}
