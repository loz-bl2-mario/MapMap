/****************************************************************************************** 
 *	Chili DirectX Framework Version 16.07.20											  *	
 *	Game.cpp																			  *
 *	Copyright 2016 PlanetChili.net <http://www.planetchili.net>							  *
 *																						  *
 *	This file is part of The Chili DirectX Framework.									  *
 *																						  *
 *	The Chili DirectX Framework is free software: you can redistribute it and/or modify	  *
 *	it under the terms of the GNU General Public License as published by				  *
 *	the Free Software Foundation, either version 3 of the License, or					  *
 *	(at your option) any later version.													  *
 *																						  *
 *	The Chili DirectX Framework is distributed in the hope that it will be useful,		  *
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of						  *
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the						  *
 *	GNU General Public License for more details.										  *
 *																						  *
 *	You should have received a copy of the GNU General Public License					  *
 *	along with The Chili DirectX Framework.  If not, see <http://www.gnu.org/licenses/>.  *
 ******************************************************************************************/
#include "MainWindow.h"
#include "Game.h"


Game::Game( MainWindow& wnd )
	:
	wnd( wnd ),
	gfx( wnd )
{
}

void Game::Go()
{ 
	gfx.BeginFrame();	
	UpdateModel();
	ComposeFrame();
	gfx.EndFrame();
}

void Game::UpdateModel()
{
	//This is a sloppy way to do movement, but the math is fine. I just don't feel like cleaning up or optimizing.
	if (wnd.kbd.KeyIsPressed(VK_RIGHT))
	{
		plane.angle += 0.1f;
		if (plane.angle > 2 * PI)
		{
			plane.angle -= 2 * PI;
		}
		plane.dx = cos(plane.angle) * 5;
		plane.dy = sin(plane.angle) * 5;
	}
	if (wnd.kbd.KeyIsPressed(VK_LEFT))
	{
		plane.angle -= 0.1f;
		if (plane.angle < 0)
		{
			plane.angle += 2 * PI;
		}
		plane.dx = cos(plane.angle) * 5;
		plane.dy = sin(plane.angle) * 5;
	}
	if (wnd.kbd.KeyIsPressed(VK_UP) && plane.canWalk)
	{
		plane.x += (plane.dx);
		plane.y += (plane.dy);
	}
	if (wnd.kbd.KeyIsPressed(VK_DOWN))
	{
		plane.x -= plane.dx;
		plane.y -= plane.dy;
	}
}
			

//vvvvvvv---I made this comment about 2 months ago. Idk what it means.
//16 x 11
void Game::ComposeFrame()
{
	plane.drawRays3d(gfx, texture);
	//These would overlay Doom Guy's HUD and guns 'n shit, but not everyone is going to be making Wolfenstein.
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	/*gfx.DrawSprite(319, 355, gun);
	gfx.DrawSprite(0, 489, Hud);*/
}