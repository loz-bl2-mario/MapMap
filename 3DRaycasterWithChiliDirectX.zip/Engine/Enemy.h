#pragma once

#include "Surface.h"
//Ignore this
class Enemy
{
public:
	void Exist();
	Surface Harris = "Harris.bmp";
	int hitBox_X = x;
	int hitBox_Y = y;
	int hitBox_Width = Harris.width;
	int hitBox_height = Harris.height;
private:
	int x;
	int y;
	int start;
	void determineStartPos( int randPos);
};
