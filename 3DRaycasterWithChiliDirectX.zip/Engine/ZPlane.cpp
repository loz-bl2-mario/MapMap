#include "ZPlane.h"

void Plane::init(Surface texture)
{
	//Load texture into array
	for (int y0 = 0; y0 < texture.height; y0++)
	{
		for (int x0 = 0; x0 < 64; x0++)
	{ 
			textCol[y0 * 64 + x0] = texture.GetPixel(x0, y0);
		}
	}
}

float Plane::dist(float ax, float ay, float bx, float by, float ang)
{
	//Archive distances for later use
	return (sqrt ( ( bx - ax) * ( bx - ax) + ( by - ay) * (by - ay)));
}

void Plane::drawRays3d(Graphics & gfx, Surface texture)
{	
	//Initialize textures
	init(texture);
	//Draw floor and ceiling as flat colors
	gfx.DrawRectDim(0, 0, 800, 300, Colors::MakeRGB(39, 39, 39));
	gfx.DrawRectDim(0, 300, 800, 300, Colors::MakeRGB(155, 155, 155));
	//Variables
	int r, mx, my, mp, dof; float rx = 0.0f, ry, ra, xo, yo;
	int Value;
	int textY = 0;
	//Set FOV---------vv
	ra = angle - DR * 30;
	//Wrap around
	if (ra < 0)
	{
		ra += 2 * PI;
	}
	if (ra > 2 * PI)
	{
		ra -= 2 * PI;
	}
	//Set Resolution----vvv
	for (int r = 0; r < 360; r++)
	{
		//Cast ray for horizontal walls
		dof = 0;
		//Big number-vvvvvvvvvv
		float disH = 1000000.0f, hx = x, hy = y;
		float aTan = -1 / tan(ra);
		if (ra > PI)
		{
			ry = (((int)y >> 6) << 6) - 0.0001;
			rx = (y - ry) * aTan + x;
			yo = -64;
			xo = -yo * aTan;
		}
		if (ra < PI)
		{
			ry = (((int)y >> 6) << 6) +64;
			rx = (y - ry) * aTan + x;
			yo = 64;
			xo = -yo * aTan;
		}
		if (ra == 0 || ra == PI)
		{
			rx = (int)x; 
			ry = (int)y;
			dof = 10;
		}
		while(dof < 10)
		{
			mx = ((int)rx) >> 6;
			my = (int)(ry) >> 6;
			mp = my * mapX + mx;
			if (mp > 0 && mp < mapX*mapY && map[mp] > 0)
			{
				textVal = map[mp];
				hx = rx;
				hy =  ry;
				disH = dist(x, y, hx, hy, ra);
				dof = 10;
			}
			else
			{
				rx += xo;
				ry += yo;
				dof += 1;
			}
		}
		//Cast for vertical walls
		dof = 0;
		/*Another big
		number-------vvvvvvvvvv*/
		float disV = 1000000.0f, vx = x, vy = y;
		float nTan = -tan(ra);
		if (ra > P2 && ra < P3)
		{
			rx = (((int)x >> 6) << 6) - 0.0001;
			ry = (x - rx) * nTan + y;
			xo = -64;
			yo = -xo * nTan;
		}
		if (ra < P2 || ra > P3)
		{
			rx = (((int)x >> 6) << 6) + 64;
			ry = (x - rx) * nTan + y;
			xo = 64;
			yo = -xo * nTan;
		}
		if (ra == 0 || ra == PI)
		{
			rx = (int)x;
			ry = (int)y;
			dof = 10;
		}
		while (dof < 10)
		{
			mx = ((int)rx) >> 6;
			my = (int)(ry) >> 6;
			mp = my * mapX + mx;
			if (mp > 0 && mp < mapX*mapY && map[mp] > 0)
			{
				textVal = map[mp];
					vx = rx;
					vy = ry;
					disV = dist(x, y, vx, vy, ra);
				dof = 10;
			}
			else
			{
				rx += xo;
				ry += yo;
				dof += 1;
			}
		}
		//Later use: determine the shorter ray
		if (disH > disV)
		{
			rx = vx;
			ry = vy;
			disT = disV;
		}
		else
		{
			rx = hx;
			ry = hy;
			disT = disH;
		}
		//Stop from walking through walls; not the most effective way
		if (r == 180)
		{
			if (disT > 50)
			{
				canWalk = true;
			}
			else
			{
				canWalk = false;
			}
		}
		//Wrap around
		float ca = angle - ra;
		if (ca < 0)
		{
			ca += 2 * PI;
		}
		if (ca > 2 * PI)
		{
			ca -= 2 * PI;
		}
		//Determine the line height based on angle & distance
		disT = disT * cos(ca);
		float lineH = (mapS * 600) / (2 *disT);
		float lineO = 300 - lineH / 2;
		if (lineH > 600)
		{
			lineH = 600;
		}
		//Sample, scale, and map pixels from the texture
		if (disH > disV)
		{			
			//Determines texture location based on map ID
			float TY = 64 * (textVal - 1);
			float TY_offset = 63.0 / (float)lineH;
			int TX = ((int)ry % 64);
			for (int y0 = lineO; y0 < lineO + lineH; y0++)
			{
				Color c = textCol[((int)TY * 64 + TX)];
				TY += TY_offset;
				gfx.PutPixel(r * 2 + 40, y0, c);
				gfx.PutPixel(r * 2 + 41, y0, c);
			}
		}
		else
		{
			float TY = 0;
			float TY_offset = 64.0 / (float)lineH;
			int TX = ((int)rx % 64);
			for (int y0 = lineO; y0 < lineO + lineH; y0++)
			{
				Color c = textCol[((int)TY * 64 + TX)];
				TY += TY_offset;
				//Subtle shading
				gfx.PutPixel(r * 2 + 40, y0, Colors::MakeRGB(c.GetR() /2, c.GetG() / 2, c.GetB() /2 ));
				gfx.PutPixel(r * 2 + 41, y0, Colors::MakeRGB(c.GetR() /2, c.GetG() / 2, c.GetB() /2 ));
			}
		}
		//Update ray angle
		//-------vvv Change this based on resolution (resolution / 6)
		ra += DR / 6;
		//"Wrap around"
		if (ra < 0)
		{
			ra += 2 * PI;
		}
		if (ra > 2 * PI)
		{
			ra -= 2 * PI;
		}
	}
	//Screen borders to hide weird FOV artifacts
	gfx.DrawRectDim(0, 0, 42, 600, Colors::Black);
	gfx.DrawRectDim(760, 0, 42, 600, Colors::Black);
}


