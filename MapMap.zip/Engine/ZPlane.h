#pragma once
#include "Graphics.h"
#include "Surface.h"
#include <math.h>
#define PI 3.14159265
#define P2 PI/2
#define P3 (3 * PI)/2
#define DR 0.0174533

class Plane
{
public:
	float x = 250.0f;
	float y = 370.0f;
	float angle = 0.0f;
	int height;
	Color textCol[4096];
	int sd = 0;
	int getFromScale(int height, int r);
	void init(Surface texture);
	float disT;
	bool canWalk = true;
	float dx = cos(angle) * 5, dy = sin(angle) * 5;
	float dist(float ax, float ay, float bx, float by, float ang);
	void drawRays3d(Graphics& gfx, Surface texture);
	int mapX = 12, mapY = 10, mapS = 120;
	int map[120] =
	{
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,1,
		1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0,1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,1,
		1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,1,
		1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,1
	};
};