#include "ZPlane.h"

int Plane::getFromScale(int height, int r)
{
	int newSize = (height * 64 + r * 2) / 64;
	return newSize;
}

void Plane::init(Surface texture)
{
	
	for (int y0 = 0; y0 < 64; y0++)
	{
		for (int x0 = 0; x0 < 64; x0++)
		{
			textCol[y0 * 64 + x0] = texture.GetPixel(x0, y0);
		}
	}
}

float Plane::dist(float ax, float ay, float bx, float by, float ang)
{
	return (sqrt ( ( bx - ax) * ( bx - ax) + ( by - ay) * (by - ay)));
}

void Plane::drawRays3d(Graphics & gfx, Surface texture)
{	init(texture);
	gfx.DrawRectDim(0, 0, 800, 300, Colors::MakeRGB(39, 39, 39));
	gfx.DrawRectDim(0, 300, 800, 300, Colors::MakeRGB(155, 155, 155));
	int r, mx, my, mp, dof; float rx = 0.0f, ry, ra, xo, yo;
	int textY = 0;
	ra = angle - DR * 30;
	if (ra < 0)
	{
		ra += 2 * PI;
	}
	if (ra > 2 * PI)
	{
		ra -= 2 * PI;
	}
	for (int r = 0; r < 360; r++)
	{

		dof = 0;
		float disH = 1000000.0f, hx = x, hy = y;
		float aTan = -1 / tan(ra);
		if (ra > PI)
		{
			ry = (((int)y >> 6) << 6) - 0.0001;
			rx = (y - ry) * aTan + x;
			yo = -64;
			xo = -yo * aTan;
		}
		if (ra < PI)
		{
			ry = (((int)y >> 6) << 6) +64;
			rx = (y - ry) * aTan + x;
			yo = 64;
			xo = -yo * aTan;
		}
		if (ra == 0 || ra == PI)
		{
			rx = (int)x; 
			ry = (int)y;
			dof = 10;
		}
		while(dof < 10)
		{
			mx = ((int)rx) >> 6;
			my = (int)(ry) >> 6;
			mp = my * mapX + mx;
			if (mp > 0 && mp < mapX*mapY && map[mp] > 0)
			{
				hx = rx;
				hy =  ry;
				disH = dist(x, y, hx, hy, ra);
				dof = 10;
			}
			else
			{
				rx += xo;
				ry += yo;
				dof += 1;
			}
		}
		//vertical
		dof = 0;
		float disV = 1000000.0f, vx = x, vy = y;
		float nTan = -tan(ra);
		if (ra > P2 && ra < P3)
		{
			rx = (((int)x >> 6) << 6) - 0.0001;
			ry = (x - rx) * nTan + y;
			xo = -64;
			yo = -xo * nTan;
		}
		if (ra < P2 || ra > P3)
		{
			rx = (((int)x >> 6) << 6) + 64;
			ry = (x - rx) * nTan + y;
			xo = 64;
			yo = -xo * nTan;
		}
		if (ra == 0 || ra == PI)
		{
			rx = (int)x;
			ry = (int)y;
			dof = 10;
		}
		while (dof < 10)
		{
			mx = ((int)rx) >> 6;
			my = (int)(ry) >> 6;
			mp = my * mapX + mx;
			if (mp > 0 && mp < mapX*mapY && map[mp] > 0)
			{
					vx = rx;
					vy = ry;
					disV = dist(x, y, vx, vy, ra);
				dof = 10;
			}
			else
			{
				rx += xo;
				ry += yo;
				dof += 1;
			}
		}
		if (disH > disV)
		{
			rx = vx;
			ry = vy;
			disT = disV;
		}
		if (disH < disV)
		{
			rx = hx;
			ry = hy;
			disT = disH;
		}
		//Render Scene
		if (r == 180)
		{
			if (disT > 50)
			{
				canWalk = true;
			}
			else
			{
				canWalk = false;
			}
		}
		float ca = angle - ra;
		if (ca < 0)
		{
			ca += 2 * PI;
		}
		if (ca > 2 * PI)
		{
			ca -= 2 * PI;
		}
		disT = disT * cos(ca);
		float lineH = (mapS * 600) / (2 *disT);
		float lineO = 300 - lineH / 2;
		if (lineH > 600)
		{
			lineH = 600;
		}
		if (disH > disV)
		{
			for (int y0 = lineO; y0 < lineO + lineH; y0++)
			{
				textY++;
				if (textY == 64)
				{
					textY = 0;
				}
				gfx.PutPixel(r * 2 + 40, y0, textCol[(int)rx / 64 + textY]);
				gfx.PutPixel(r * 2 + 41, y0, textCol[(int)rx / 64 + textY]);
			}
			//gfx.DrawLine(r * 2 + 40, lineO, r * 2 + 40, lineH + lineO, Colors::MakeRGB(0, 0, 110));
			//gfx.DrawLine(r * 2 + 41, lineO, r * 2 + 41, lineH + lineO, Colors::MakeRGB(0, 0, 110));	
		}
		if (disH < disV)
		{
				gfx.DrawLine(r * 2 + 40, lineO, r * 2 + 40, (lineH + lineO), Colors::MakeRGB(3, 0, 133));
				gfx.DrawLine(r * 2 + 41, lineO, r * 2 + 41, (lineH + lineO), Colors::MakeRGB(3, 0, 133));
		}
		ra += DR / 6;
		if (ra < 0)
		{
			ra += 2 * PI;
		}
		if (ra > 2 * PI)
		{
			ra -= 2 * PI;
		}
	}
	gfx.DrawRectDim(0, 0, 42, 600, Colors::Black);
	gfx.DrawRectDim(760, 0, 42, 600, Colors::Black);
	}


